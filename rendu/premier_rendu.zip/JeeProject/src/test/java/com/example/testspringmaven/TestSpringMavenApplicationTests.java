package com.example.testspringmaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpringMavenApplicationTests {

    @Test
    void contextLoads() {
    }

}
